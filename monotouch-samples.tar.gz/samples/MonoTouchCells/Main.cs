//
// The TouchCells sample ported to C#
//
using System;
using System.Collections.Generic;
using System.Collections;

//
// Import the MonoTouch namespaces
//
using MonoTouch.CoreGraphics;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

public class MainClass {
	
	static void Main (string [] args)
	{
		UIApplication.Main(args, null, null);		
	}
}