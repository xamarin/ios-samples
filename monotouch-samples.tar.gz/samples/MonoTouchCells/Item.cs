
using System;
using System.Xml.Serialization;

namespace MonoTouchCells
{

	public class Item
	{
		
		public string Title { get; set; }
		
		public bool Checked { get; set; }
		
		public Item ()
		{
			
		}
	}
}
