//
// Wayup auto-generated outlets C#
//

using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using System.Drawing;

public partial class WhichWayIsUpAppDelegate : UIApplicationDelegate {
	[Connect]
	public UIWindow window {
		get {
			return (UIWindow) GetNativeField ("window");
		}
		set {
			SetNativeField ("window", value);
		}
	}

	[Connect]
	public CrateViewController crateViewController {
		get {
			return (CrateViewController) GetNativeField ("crateViewController");
		}
		set {
			SetNativeField ("crateViewController", value);
		}
			
	}
	
}
